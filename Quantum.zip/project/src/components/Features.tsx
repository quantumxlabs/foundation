import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Zap, Scale } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Quantum Security',
    description: 'Unbreakable encryption powered by quantum mechanics for ultimate data protection.'
  },
  {
    icon: Zap,
    title: 'Lightning Speed',
    description: 'Process complex calculations in seconds that would take classical computers years.'
  },
  {
    icon: Scale,
    title: 'Infinite Scalability',
    description: 'Scale your quantum operations seamlessly with our distributed architecture.'
  }
];

const Features = () => {
  return (
    <section className="py-20 bg-[#0A0A0A]">
      <div className="container mx-auto px-4">
        <motion.h2 
          className="text-4xl font-bold text-center mb-16 gradient-text"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          Core Innovations
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className="feature-card"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
            >
              <feature.icon className="w-12 h-12 mb-4 text-[#00FFA3]" />
              <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;