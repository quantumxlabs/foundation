import React, { Suspense } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Canvas } from '@react-three/fiber';
import { Logo3D } from './Logo3D';
import { Environment, OrbitControls } from '@react-three/drei';

const Hero = () => {
  return (
    <motion.section 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
      className="min-h-screen flex items-center justify-center relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-[#0A0A0A] via-[#1A1A1A] to-[#0A0A0A] z-0" />
      
      {/* 3D Logo */}
      <div className="absolute inset-0 z-10">
        <Canvas camera={{ position: [0, 0, 5] }}>
          <Suspense fallback={null}>
            <Logo3D />
            <Environment preset="city" />
            <OrbitControls enableZoom={false} />
          </Suspense>
        </Canvas>
      </div>
      
      {/* Floating particles */}
      <div className="absolute inset-0 z-10 pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-[#00FFA3] rounded-full opacity-20"
            animate={{
              x: [0, Math.random() * 100 - 50],
              y: [0, Math.random() * 100 - 50],
            }}
            transition={{
              duration: Math.random() * 3 + 2,
              repeat: Infinity,
              repeatType: "reverse"
            }}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-4 text-center relative z-20">
        <div className="mb-16">
          <img 
            src="https://i.imgur.com/YourLogoURL.png" 
            alt="QuantumX Labs Logo" 
            className="w-24 h-24 mx-auto mb-8"
          />
        </div>
        
        <motion.h1 
          className="text-6xl md:text-7xl font-bold mb-6"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          Welcome to{' '}
          <span className="gradient-text">QuantumX Labs</span>
        </motion.h1>

        <motion.p 
          className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          Pioneering the next generation of quantum computing solutions for a 
          future where impossible becomes possible.
        </motion.p>

        <motion.button
          className="gradient-border bg-[#1A1A1A] text-white px-8 py-4 rounded-lg flex items-center gap-2 mx-auto hover:scale-105 transition-transform duration-300"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Explore Our Solutions
          <ArrowRight className="w-5 h-5" />
        </motion.button>
      </div>
    </motion.section>
  );
};

export default Hero;