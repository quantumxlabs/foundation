import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGLTF, MeshDistortMaterial } from '@react-three/drei';
import * as THREE from 'three';

export function Logo3D() {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = state.clock.getElapsedTime() * 0.5;
    }
  });

  return (
    <mesh ref={meshRef} scale={[2, 2, 2]}>
      <octahedronGeometry args={[1, 0]} />
      <MeshDistortMaterial
        color="#00FFA3"
        attach="material"
        distort={0.3}
        speed={2}
        roughness={0}
        metalness={1}
      />
    </mesh>
  );
}