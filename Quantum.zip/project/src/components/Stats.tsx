import React from 'react';
import { motion } from 'framer-motion';

const stats = [
  { label: 'Quantum Transactions/sec', value: '1M+' },
  { label: 'Network Uptime', value: '99.999%' },
  { label: 'Quantum Nodes', value: '10K+' },
  { label: 'Countries Served', value: '50+' }
];

const Stats = () => {
  return (
    <section className="py-20 bg-[#1A1A1A]">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <motion.div 
                className="text-4xl font-bold gradient-text mb-2"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ 
                  duration: 2,
                  repeat: Infinity,
                  repeatType: "reverse"
                }}
              >
                {stat.value}
              </motion.div>
              <div className="text-gray-400">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;